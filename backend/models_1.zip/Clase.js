import mongoose from "mongoose";

// Definición del Sub-Esquema para el Horario (Día)
const DiaHorarioSchema = new mongoose.Schema({
    idDia: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'DiaSemana',
        default: null, // Null si no hay clase ese día
    }
}, { _id: false });

const ClaseSchema = new mongoose.Schema({
    // Campos Originales de Clase
    idGrupo: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Grupo',
        required: true,
    },
    idMateria: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Materia',
        required: true,
    },
    cupoMaximo: {
        type: Number,
        default: 30,
        min: 1,
    },
    idProfesor: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Usuario', // Referencia a Usuario, asumiendo que es Profesor
        required: true,
    },
    // Horario Incrustado (Mejor Práctica NoSQL para 1:1)
    horario: {
        lunes: DiaHorarioSchema,
        martes: DiaHorarioSchema,
        miercoles: DiaHorarioSchema,
        jueves: DiaHorarioSchema,
        viernes: DiaHorarioSchema,
        sabado: DiaHorarioSchema,
    }
}, { timestamps: true });

// Índice compuesto para prevenir clases duplicadas en el mismo grupo/materia
ClaseSchema.index({ idGrupo: 1, idMateria: 1 });

export const Clase = mongoose.model("Clase", ClaseSchema);