import mongoose from "mongoose";

const InscripcionClaseSchema = new mongoose.Schema({
    idClase: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Clase', // Referencia a Usuario, se asume que es Alumno
        required: true,
    },
    idInscripcion: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Inscripcion', // Referencia a Usuario, se asume que es Alumno
        required: true,
    },
}, { timestamps: true });

// Índice único para evitar doble inscripción del mismo alumno en la misma materia
InscripcionClaseSchema.index({ idInscripcion: 1, idClase: 1 }, { unique: true });

export const InscripcionClase = mongoose.model("InscripcionClase", InscripcionClaseSchema);
