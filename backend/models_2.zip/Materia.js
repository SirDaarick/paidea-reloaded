import mongoose from "mongoose";

const MateriaSchema = new mongoose.Schema({
    clave: {
        type: String,
        required: true,
        unique: true,
        trim: true,
    },
    nombre: {
        type: String,
        required: true,
        trim: true,
    },
    creditos: {
        type: Number,
        required: true,
        min: 0,
    },
    optativa: {
        type: Boolean,
        default: false,
    },
    // Relación many-to-many consigo misma (Prerrequisitos)
    prerrequisitos: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Materia',
    }]
}, { timestamps: true });

export const Materia = mongoose.model("Materia", MateriaSchema);
