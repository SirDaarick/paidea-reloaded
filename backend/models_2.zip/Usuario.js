import mongoose from "mongoose";

// --- ESQUEMAS DE USUARIOS Y ROLES (CONSOLIDACIÓN) ---

// Sub-esquema para Datos Personales (1:1, embebido en Usuario)
const DatosPersonalesSchema = new mongoose.Schema({
    curp: {
        type: String,
        required: true,
        sparse: true, // Permite valores nulos
        unique: true,
        uppercase: true,
        trim: true,
    },
    rfc: {
        type: String,
        sparse: true, // Permite valores nulos
        unique: true,
        uppercase: true,
        trim: true,
    },
    nacimiento: Date,
    nacionalidad: String,
    plantel: String,
    telefono: String,
}, { _id: false }); // No queremos un _id separado para este subdocumento

// Sub-esquema para Dirección (1:N, embebido como array en Usuario)
const DireccionSchema = new mongoose.Schema({
    estado: String,
    delegacion: String,
    colonia: String,
    calle: String,
    noExt: String,
    noInt: String,
    cp: String,
}, { _id: false });


// Sub-esquema para la especialización Alumno
const AlumnoDataSchema = new mongoose.Schema({
    idCarrera: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Carrera',
            required: true,
        },
    promedio: {
        type: Number,
        min: 0,
        max: 10,
    },
    creditosCursados: {
        type: Number,
        default: 0,
        min: 0,
    },
    creditosFaltantes: {
        type: Number,
        default: 0,
        min: 0,
    },
    situacionEscolar: String,
}, { _id: false });

// Sub-esquema para la especialización Profesor
const ProfesorDataSchema = new mongoose.Schema({
    departamento: String,
}, { _id: false });


/**
 * Esquema de Usuario (Consolida Usuario, Datos_personales, Datos_Medicos, Alumnos, Profesores)
 * La información de rol (Alumno/Profesor) se gestiona de forma condicional.
 */
const UsuarioSchema = new mongoose.Schema({
    nombre: {
        type: String,
        required: true,
        trim: true,
    },
    correo: {
        type: String,
        required: true,
        sparse: true, // Permite valores nulos
        unique: true,
        lowercase: true,
        trim: true,
    },
    contrasena: {
        type: String,
        required: true,
    },
    rol: {
        type: String,
        required: true,
        enum: ['Alumno', 'Profesor', 'Administrativo'], // Se extiende el rol para ser más útil
    },
    // Datos embebidos (1:1)
    datosPersonales: {
        type: DatosPersonalesSchema,
        required: true,
    },
    // Direcciones embebidas (1:N)
    direcciones: [DireccionSchema],

    // Datos específicos de rol (Aparecen si el rol coincide)
    dataAlumno: {
        type: AlumnoDataSchema,
        required: function() { return this.rol === 'Alumno'; } // Requerido solo si el rol es 'Alumno'
    },
    dataProfesor: {
        type: ProfesorDataSchema,
        required: function() { return this.rol === 'Profesor'; } // Requerido solo si el rol es 'Profesor'
    }
}, { timestamps: true });

// Índice para búsquedas por correo y rol
UsuarioSchema.index({ correo: 1, rol: 1 });

export const Usuario = mongoose.model("Usuario", UsuarioSchema);