import express from 'express';
import { Calificacion } from '../models/Calificacion.js'; // Ajusta la ruta si es necesario

const router = express.Router();

// --- Rutas CRUD para Calificaciones --- //

router.get('/', async (req, res) => {
    try {
        const calificaciones = await Calificacion.find()
            .populate('idInscripcion') 
            .populate('idClase');      
        res.status(200).json(calificaciones);
    } catch (error) {
        console.error("Error al obtener las calificaciones:", error);
        res.status(500).json({ error: 'Error al obtener las calificaciones', detalle: error.message });
    }
});


router.get('/:id', async (req, res) => {
    try {
        const calificacion = await Calificacion.findById(req.params.id)
            .populate('idInscripcion')
            .populate('idClase');
            
        if (!calificacion) {
            return res.status(404).json({ error: 'Calificación no encontrada' });
        }
        res.status(200).json(calificacion);
    } catch (error) {
        console.error("Error al obtener la calificación:", error);
        res.status(500).json({ error: 'Error al obtener la calificación', detalle: error.message });
    }
});



router.post('/', async (req, res) => {
    try {
        const calificacion = new Calificacion(req.body);
        const savedCalificacion = await calificacion.save();
        res.status(201).json(savedCalificacion);
    } catch (error) {
        console.error("Error al crear la calificación:", error);

        // Mongoose Validation Error (ej. campos requeridos, min/max en 'valor')
        if (error.name === 'ValidationError') {
            return res.status(400).json({ error: 'Error de validación al crear la calificación', detalle: error.message });
        }
        
        res.status(500).json({ error: 'Error interno al crear la calificación', detalle: error.message });
    }
});


router.put('/:id', async (req, res) => {
    try {
        const updatedCalificacion = await Calificacion.findByIdAndUpdate(
            req.params.id, 
            req.body, 
            { new: true, runValidators: true } // Ejecutar validadores para min/max
        );

        if (!updatedCalificacion) {
            return res.status(404).json({ error: 'Calificación no encontrada' });
        }
        res.status(200).json(updatedCalificacion);
    } catch (error) {
        console.error("Error al actualizar la calificación:", error);

        if (error.name === 'ValidationError') {
            return res.status(400).json({ error: 'Error de validación al actualizar la calificación', detalle: error.message });
        }

        res.status(500).json({ error: 'Error al actualizar la calificación', detalle: error.message });
    }
});


router.delete('/:id', async (req, res) => {
    try {
        const deletedCalificacion = await Calificacion.findByIdAndDelete(req.params.id);
        if (!deletedCalificacion) {
            return res.status(404).json({ error: 'Calificación no encontrada' });
        }
        res.status(200).json({ message: 'Calificación eliminada correctamente' });
    } catch (error) {
        console.error("Error al eliminar la calificación:", error);
        res.status(500).json({ error: 'Error al eliminar la calificación', detalle: error.message });
    }
});

export default router;