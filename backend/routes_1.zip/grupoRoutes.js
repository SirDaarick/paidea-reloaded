import express from 'express';
import { Grupo } from '../models/Grupo.js'; // Ajusta la ruta si es necesario

const router = express.Router();

// --- Rutas CRUD para Grupos --- //

router.get('/', async (req, res) => {
    try {
        const grupos = await Grupo.find()
            .populate('idCarrera')      // Traer datos de la Carrera
            .populate('idPeriodo');     // Traer datos del PeriodoAcademico
        res.status(200).json(grupos);
    } catch (error) {
        console.error("Error al obtener los grupos:", error);
        res.status(500).json({ error: 'Error al obtener los grupos', detalle: error.message });
    }
});


router.get('/:id', async (req, res) => {
    try {
        const grupo = await Grupo.findById(req.params.id)
            .populate('idCarrera')
            .populate('idPeriodo');
            
        if (!grupo) {
            return res.status(404).json({ error: 'Grupo no encontrado' });
        }
        res.status(200).json(grupo);
    } catch (error) {
        console.error("Error al obtener el grupo:", error);
        res.status(500).json({ error: 'Error al obtener el grupo', detalle: error.message });
    }
});


router.post('/', async (req, res) => {
    try {
        const grupo = new Grupo(req.body);
        const savedGrupo = await grupo.save();
        res.status(201).json(savedGrupo);
    } catch (error) {
        console.error("Error al crear el grupo:", error);

        // Mongoose Validation Error (ej. campos requeridos, 'enum' en turno, 'min' en semestre)
        if (error.name === 'ValidationError') {
            return res.status(400).json({ error: 'Error de validación al crear el grupo', detalle: error.message });
        }
        
        res.status(500).json({ error: 'Error interno al crear el grupo', detalle: error.message });
    }
});

router.put('/:id', async (req, res) => {
    try {
        const updatedGrupo = await Grupo.findByIdAndUpdate(
            req.params.id, 
            req.body, 
            { new: true, runValidators: true } // Ejecutar validadores para 'min' y 'enum'
        );

        if (!updatedGrupo) {
            return res.status(404).json({ error: 'Grupo no encontrado' });
        }
        res.status(200).json(updatedGrupo);
    } catch (error) {
        console.error("Error al actualizar el grupo:", error);

        if (error.name === 'ValidationError') {
            return res.status(400).json({ error: 'Error de validación al actualizar el grupo', detalle: error.message });
        }

        res.status(500).json({ error: 'Error al actualizar el grupo', detalle: error.message });
    }
});


router.delete('/:id', async (req, res) => {
    try {
        const deletedGrupo = await Grupo.findByIdAndDelete(req.params.id);
        if (!deletedGrupo) {
            return res.status(404).json({ error: 'Grupo no encontrado' });
        }
        res.status(200).json({ message: 'Grupo eliminado correctamente' });
    } catch (error) {
        console.error("Error al eliminar el grupo:", error);
        res.status(500).json({ error: 'Error al eliminar el grupo', detalle: error.message });
    }
});

export default router;