import express from "express";
import { InscripcionClase } from "../models/InscripcionClase.js";


const router = express.Router();
// --- Rutas CRUD para Inscripciones a Clases --- //

router.get("/", async (req, res) => {
    try {
        const inscripcionesClase = await InscripcionClase.find()
            .populate('idInscripcion') // Traer datos relevantes de la Inscripción
            .populate('idClase');
        res.status(200).json(inscripcionesClase);
    } catch (error) {
        console.error("Error al obtener las inscripciones a clases:", error);
        res.status(500).json({ error: "Error al obtener las inscripciones a clases", detalle: error.message });
    }
})

router.get("/:id", async (req, res) => {
    try {
        const inscripcionClase = await InscripcionClase.findById(req.params.id)
            .populate('idInscripcion')
            .populate('idClase');
        if (!inscripcionClase) {
            return res.status(404).json({ error: "Inscripción a clase no encontrada" });
        }
        res.status(200).json(inscripcionClase);
    } catch (error) {
        console.error("Error al obtener la inscripción a clase:", error);
        res.status(500).json({ error: "Error al obtener la inscripción a clase", detalle: error.message });
    }
})


router.post("/", async (req, res) => {
    try {
        const inscripcionClase = new InscripcionClase(req.body);
        const savedInscripcionClase = await inscripcionClase.save();
        res.status(201).json(savedInscripcionClase);
    } catch (error) {
        console.error("Error al crear la inscripción a clase:", error);
        res.status(500).json({ error: "Error al crear la inscripción a clase", detalle: error.message });
    }
})


router.put("/:id", async (req, res) => {
    try {
        const updatedInscripcionClase = await InscripcionClase.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
        if (!updatedInscripcionClase) {
            return res.status(404).json({ error: "Inscripción a clase no encontrada" });
        }
        res.status(200).json(updatedInscripcionClase);
    } catch (error) {
        console.error("Error al actualizar la inscripción a clase:", error);
        res.status(500).json({ error: "Error al actualizar la inscripción a clase", detalle: error.message });
    }
})

router.delete("/:id", async (req, res) => {
    try {
        const deletedInscripcionClase = await InscripcionClase.findByIdAndDelete(req.params.id);
        if (!deletedInscripcionClase) {
            return res.status(404).json({ error: "Inscripción a clase no encontrada" });
        }
        res.status(200).json({ message: "Inscripción a clase eliminada correctamente" });
    } catch (error) {
        console.error("Error al eliminar la inscripción a clase:", error);
        res.status(500).json({ error: "Error al eliminar la inscripción a clase", detalle: error.message });
    }
})

export default router;