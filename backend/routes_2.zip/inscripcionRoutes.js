import express from 'express';
import { Inscripcion } from '../models/Inscripcion.js'; // Ajusta la ruta si es necesario

const router = express.Router();

// --- Rutas CRUD para Inscripciones --- //


router.get('/', async (req, res) => {
    try {
        const inscripciones = await Inscripcion.find()
            .populate('idAlumno', 'nombre correo datosPersonales.curp') // Traer datos relevantes del Alumno
            .populate('idPeriodo');                                     // Traer datos de la Materia
        res.status(200).json(inscripciones);
    } catch (error) {
        console.error("Error al obtener las inscripciones:", error);
        res.status(500).json({ error: 'Error al obtener las inscripciones', detalle: error.message });
    }
});


router.get('/:id', async (req, res) => {
    try {
        const inscripcion = await Inscripcion.findById(req.params.id)
            .populate('idAlumno', 'nombre correo datosPersonales.curp')
            .populate('idPeriodo');
            
        if (!inscripcion) {
            return res.status(404).json({ error: 'Inscripción no encontrada' });
        }
        res.status(200).json(inscripcion);
    } catch (error) {
        console.error("Error al obtener la inscripción:", error);
        res.status(500).json({ error: 'Error al obtener la inscripción', detalle: error.message });
    }
});


router.post('/', async (req, res) => {
    try {
        const inscripcion = new Inscripcion(req.body);
        const savedInscripcion = await inscripcion.save();
        res.status(201).json(savedInscripcion);
    } catch (error) {
        console.error("Error al crear la inscripción:", error);

        // Mongoose Validation Error (ej. campos requeridos, min en creditos)
        if (error.name === 'ValidationError') {
            return res.status(400).json({ error: 'Error de validación al crear la inscripción', detalle: error.message });
        }
        // Duplicate Key Error (índice único: idAlumno y idMateria)
        if (error.code === 11000) {
            return res.status(400).json({ error: 'Inscripción duplicada', detalle: 'El alumno ya está inscrito en esta materia.' });
        }
        
        res.status(500).json({ error: 'Error interno al crear la inscripción', detalle: error.message });
    }
});


router.put('/:id', async (req, res) => {
    try {
        const updatedInscripcion = await Inscripcion.findByIdAndUpdate(
            req.params.id, 
            req.body, 
            { new: true, runValidators: true } // Ejecutar validadores para 'min'
        );

        if (!updatedInscripcion) {
            return res.status(404).json({ error: 'Inscripción no encontrada' });
        }
        res.status(200).json(updatedInscripcion);
    } catch (error) {
        console.error("Error al actualizar la inscripción:", error);

        if (error.name === 'ValidationError') {
            return res.status(400).json({ error: 'Error de validación al actualizar la inscripción', detalle: error.message });
        }
        if (error.code === 11000) {
            return res.status(400).json({ error: 'Inscripción duplicada', detalle: 'Los cambios resultan en una doble inscripción del mismo alumno en la misma materia.' });
        }

        res.status(500).json({ error: 'Error al actualizar la inscripción', detalle: error.message });
    }
});


router.delete('/:id', async (req, res) => {
    try {
        const deletedInscripcion = await Inscripcion.findByIdAndDelete(req.params.id);
        if (!deletedInscripcion) {
            return res.status(404).json({ error: 'Inscripción no encontrada' });
        }
        res.status(200).json({ message: 'Inscripción eliminada correctamente' });
    } catch (error) {
        console.error("Error al eliminar la inscripción:", error);
        res.status(500).json({ error: 'Error al eliminar la inscripción', detalle: error.message });
    }
});

export default router;