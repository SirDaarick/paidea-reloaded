import express from 'express';
import { Usuario } from '../models/Usuario.js'; 
const router = express.Router();

//--- Rutas CRUD para Usuarios ---//

router.get('/', async (req, res) => {
    try {
        // Se utiliza el método .find() para traer todos los documentos.
        // No se requiere .populate() ya que todos los sub-documentos están embebidos.
        const usuarios = await Usuario.find({});
        res.status(200).json(usuarios);
    } catch (error) {
        console.error("Error al obtener los usuarios:", error);
        res.status(500).json({ error: 'Error al obtener los usuarios', detalle: error.message });
    }
});


router.get('/:id', async (req, res) => {
    try {
        const usuario = await Usuario.findById(req.params.id);
        if (!usuario) {
            return res.status(404).json({ error: 'Usuario no encontrado' });
        }
        res.status(200).json(usuario);
    } catch (error) {
        console.error("Error al obtener el usuario:", error);
        res.status(500).json({ error: 'Error al obtener el usuario', detalle: error.message });
    }
});


router.post('/', async (req, res) => {
    try {
        const usuario = new Usuario(req.body);
        const savedUsuario = await usuario.save();
        res.status(201).json(savedUsuario);
    } catch (error) {
        console.error("Error al crear el usuario:", error);

        // Mongoose Validation Error (ej. campos requeridos, 'unique', 'enum')
        if (error.name === 'ValidationError') {
            return res.status(400).json({ error: 'Error de validación al crear el usuario', detalle: error.message });
        }
        // Duplicate Key Error (ej. 'unique: true' en correo o curp)
        if (error.code === 11000) {
            return res.status(400).json({ error: 'Datos duplicados', detalle: 'El correo, CURP o NSS ya existe.' });
        }

        res.status(500).json({ error: 'Error interno al crear el usuario', detalle: error.message });
    }
});


router.put('/:id', async (req, res) => {
    try {
        // Ejecutar validadores al actualizar para manejar campos condicionales (dataAlumno/dataProfesor)
        const updatedUsuario = await Usuario.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        );

        if (!updatedUsuario) {
            return res.status(404).json({ error: 'Usuario no encontrado' });
        }
        res.status(200).json(updatedUsuario);
    } catch (error) {
        console.error("Error al actualizar el usuario:", error);

        if (error.name === 'ValidationError') {
            return res.status(400).json({ error: 'Error de validación al actualizar el usuario', detalle: error.message });
        }
        if (error.code === 11000) {
            return res.status(400).json({ error: 'Datos duplicados', detalle: 'El correo, CURP o NSS ya existe en otro usuario.' });
        }

        res.status(500).json({ error: 'Error interno al actualizar el usuario', detalle: error.message });
    }
});


router.delete('/:id', async (req, res) => {
    try {
        const deletedUsuario = await Usuario.findByIdAndDelete(req.params.id);
        if (!deletedUsuario) {
            return res.status(404).json({ error: 'Usuario no encontrado' });
        }
        res.status(200).json({ message: 'Usuario eliminado correctamente' });
    } catch (error) {
        console.error("Error al eliminar el usuario:", error);
        res.status(500).json({ error: 'Error al eliminar el usuario', detalle: error.message });
    }
});

export default router;